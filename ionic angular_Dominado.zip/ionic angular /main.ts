import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge } from '@ionic/angular/standalone';

@Component({selector:'app-contact-us', standalone:true, imports:[CommonModule, RouterLink, FormsModule, ReactiveFormsModule, IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge], templateUrl:'./contact-us.page.html', styleUrls:['./contact-us.page.scss']})
export class ContactUsPage {
constructor(private fb: FormBuilder){} form=this.fb.group({name:['',Validators.required],email:['',[Validators.required,Validators.email]],message:['',Validators.required]}); submitted=false; submit(){ if(this.form.valid){this.submitted=true; this.form.reset();} else {this.form.markAllAsTouched();} }
}
