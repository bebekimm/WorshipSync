import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge } from '@ionic/angular/standalone';

@Component({selector:'app-event-details', standalone:true, imports:[CommonModule, RouterLink, FormsModule, ReactiveFormsModule, IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge], templateUrl:'./event-details.page.html', styleUrls:['./event-details.page.scss']})
export class EventDetailsPage {
joined=false;
events=[
{id:1,title:'Sunday Worship Gathering',date:'May 5, 2026',time:'9:00 AM',location:'Main Sanctuary',description:'Praise, teaching, communion, and fellowship for the whole church family. Come early for coffee and welcome time.'},
{id:2,title:'Youth Praise Night',date:'May 9, 2026',time:'6:30 PM',location:'Youth Hall',description:'A vibrant evening of worship, testimony, games, and small group encouragement for students.'},
{id:3,title:'Prayer and Healing Service',date:'May 14, 2026',time:'7:00 PM',location:'Prayer Chapel',description:'A quiet night of intercession, worship, and encouragement with ministry leaders available for prayer.'}
];
event=this.events[0];
constructor(private route: ActivatedRoute){ const id=Number(this.route.snapshot.paramMap.get('id')); this.event=this.events.find(e=>e.id===id)||this.events[0]; }
}
