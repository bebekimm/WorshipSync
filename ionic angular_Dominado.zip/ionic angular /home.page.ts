import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge } from '@ionic/angular/standalone';

@Component({selector:'app-login', standalone:true, imports:[CommonModule, RouterLink, FormsModule, ReactiveFormsModule, IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge], templateUrl:'./login.page.html', styleUrls:['./login.page.scss']})
export class LoginPage {
constructor(private fb: FormBuilder, private router: Router){}
form=this.fb.group({email:['',[Validators.required,Validators.email]],password:['',[Validators.required,Validators.minLength(6)]]});
login(){ if(this.form.valid){this.router.navigateByUrl('/tabs/home')} else {this.form.markAllAsTouched()} }
}
