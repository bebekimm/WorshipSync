import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge } from '@ionic/angular/standalone';

@Component({selector:'app-profile', standalone:true, imports:[CommonModule, RouterLink, FormsModule, ReactiveFormsModule, IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge], templateUrl:'./profile.page.html', styleUrls:['./profile.page.scss']})
export class ProfilePage {
constructor(private router: Router){} logout(){this.router.navigateByUrl('/login')}
}
