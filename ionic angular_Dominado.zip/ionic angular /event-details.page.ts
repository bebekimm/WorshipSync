import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { Router, RouterLink, ActivatedRoute } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge } from '@ionic/angular/standalone';

@Component({selector:'app-worship-songs', standalone:true, imports:[CommonModule, RouterLink, FormsModule, ReactiveFormsModule, IonContent, IonHeader, IonToolbar, IonTitle, IonButtons, IonBackButton, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonButton, IonIcon, IonList, IonItem, IonLabel, IonInput, IonTextarea, IonSearchbar, IonToggle, IonAvatar, IonBadge], templateUrl:'./worship-songs.page.html', styleUrls:['./worship-songs.page.scss']})
export class WorshipSongsPage {
searchTerm='';
songs=[
{id:1,title:'Holy Forever',artist:'Chris Tomlin',category:'Praise',lyrics:'A thousand generations falling down in worship, singing holy is the Lord.'},
{id:2,title:'Goodness of God',artist:'Bethel Music',category:'Worship',lyrics:'All my life You have been faithful. All my life You have been so good.'},
{id:3,title:'Build My Life',artist:'Pat Barrett',category:'Prayer',lyrics:'I will build my life upon Your love, it is a firm foundation.'},
{id:4,title:'Here Again',artist:'Elevation Worship',category:'Reflection',lyrics:'Not for a minute was I forsaken. The Lord is in this place.'}
];
get filteredSongs(){const q=this.searchTerm.toLowerCase();return this.songs.filter(s=>s.title.toLowerCase().includes(q)||s.artist.toLowerCase().includes(q)||s.category.toLowerCase().includes(q));}
}
